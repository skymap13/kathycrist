import React from "react";
import { useRouter } from "next/router";
import Layout from "@/components/Layout";
import { useQuery, gql, useMutation } from "@apollo/client";
import { Formik } from "formik";
import * as Yup from 'yup';
import Swal from "sweetalert2";


const OBTENER_CIENTE = gql`
  query obtenerClienteID($id: ID!) {
    obtenerClienteID(id: $id) {
      id
      nombre
      apellido
      cedula
      email
      telefono
    }
  }
`;

const ACTUALIZAR_CLIENTE = gql`
mutation actualizarCliente($id: ID!, $input:ClienteInput){
    actualizarCliente(id: $id, input:$input){
        id
        nombre
        apellido
        cedula
        email
        telefono
    }
  }
`;

const EditarCliente = () => {
  //obtener el ID actual
  const router = useRouter();
  const {
    query: { id },
  } = router;
 // console.log(id);

  //consultar para obtner el cliente
  const { data, loading, error } = useQuery(OBTENER_CIENTE, {
    variables: {
      id,
    },
  });

  //Actualizar el cliente
  const [actualizarCliente] = useMutation(ACTUALIZAR_CLIENTE);

  //Schema de validacion
  const schemaValidacion = Yup.object({
    nombre:Yup.string().required('El nombre es obligatorio'),
    apellido: Yup.string().required('El apellido es obligatorio'),
    cedula: Yup.string().required('La cédula es obligatoria'),
    email: Yup.string().email('El correo no es válido').required('El correo es obligatorio'),
    telefono: Yup.number().required('El télefono es obligatorio')
});

  //console.log(data);
  //console.log(loading);
  //console.log(error);
  if (loading) return "Cargando...";

  //console.log(data.obtenerClienteID);

    const{obtenerClienteID}=data;

    //Modificar el cliente en la BD
    const actualizarInfoCliente =async valores=>{
        const {nombre, apellido,cedula, email, telefono} = valores;

        try {
            const{data}=await actualizarCliente({
                variables:{
                    id,
                    input:{
                        nombre,
                        apellido,
                        cedula,
                        email,
                        telefono
                    }
                }
            })
            //console.log(data);
            // SweetAlert
            Swal.fire("Actualizado!", 'La información se actualizo correctamente', "success");

            // REDIRECCIONAR
                router.push('/');

        } catch (error) {
            console.log(error);
        }
    }

  return (
    <Layout>
      <h1 className="text-2xl text-gray-800 font-light">Editar Cliente</h1>

      <div className="flex justify-center mt-5">
        <div className="w-full max-w-lg">
          <Formik
            validationSchema={schemaValidacion}
            enableReinitialize
            initialValues={obtenerClienteID}
            onSubmit={( valores) =>{
                actualizarInfoCliente(valores)
            }
                
            }
          >
            {(props) => {
              //console.log(props);
              return (
                <form
                  className="bg-white shadow-md px-8 pt-6 pb-8 mb-4"
                    onSubmit={props.handleSubmit}
                >
                  <div className="mb-4">
                    <label
                      className="block text-gray-700 text-sm font-bold mb-2"
                      htmlFor="nombre"
                    >
                      Nombre:
                    </label>
                    <input
                      className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-none"
                      id="nombre"
                      type="text"
                      placeholder="Nombre Cliente"
                        onChange={props.handleChange}
                        onBlur={props.handleBlur}
                        value={props.values.nombre}
                    />
                  </div>
                  
                    {props.touched.nombre && props.errors.nombre ? (
                        <div className="my-2 bg-red-100 border-l-4 border-red-500 text-red-700 p-4">
                            <p className="font-bold">ERROR</p>
                             <p>{props.errors.nombre}</p>
                        </div>
                        ): null}
            
                  <div className="mb-4">
                    <label
                      className="block text-gray-700 text-sm font-bold mb-2"
                      htmlFor="apellido"
                    >
                      Apellido:
                    </label>
                    <input
                      className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-none"
                      id="apellido"
                      type="text"
                      placeholder="Apellido Cliente"
                      onChange={props.handleChange}
                      onBlur={props.handleBlur}
                      value={props.values.apellido}
                    />
                  </div>
                
            {props.touched.apellido && props.errors.apellido ? (
                        <div className="my-2 bg-red-100 border-l-4 border-red-500 text-red-700 p-4">
                            <p className="font-bold">ERROR</p>
                            <p>{props.errors.apellido}</p>
                        </div>
                        ): null}
            
                  <div className="mb-4">
                    <label
                      className="block text-gray-700 text-sm font-bold mb-2"
                      htmlFor="cedula"
                    >
                      Cédula:
                    </label>
                    <input
                      className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-none"
                      id="cedula"
                      type="text"
                      placeholder="Cedula Cliente"
                      onChange={props.handleChange}
                      onBlur={props.handleBlur}
                      value={props.values.cedula}
                    />
                  </div>
                
            {props.touched.cedula && props.errors.cedula ? (
                        <div className="my-2 bg-red-100 border-l-4 border-red-500 text-red-700 p-4">
                            <p className="font-bold">ERROR</p>
                            <p>{props.errors.cedula}</p>
                        </div>
                        ): null}
     
                  <div className="mb-4">
                    <label
                      className="block text-gray-700 text-sm font-bold mb-2"
                      htmlFor="email"
                    >
                      Correo:
                    </label>
                    <input
                      className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-none"
                      id="email"
                      type="email"
                      placeholder="Correo Cliente"
                      onChange={props.handleChange}
                      onBlur={props.handleBlur}
                    value={props.values.email}
                    />
                  </div>
                
            {props.touched.email && props.errors.email ? (
                        <div className="my-2 bg-red-100 border-l-4 border-red-500 text-red-700 p-4">
                            <p className="font-bold">ERROR</p>
                            <p>{props.errors.email}</p>
                        </div>
                        ): null}
            
                  <div className="mb-4">
                    <label
                      className="block text-gray-700 text-sm font-bold mb-2"
                      htmlFor="telefono"
                    >
                      Teléfono:
                    </label>
                    <input
                      className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-none"
                      id="telefono"
                      type="tel"
                      placeholder="Teléfono Cliente"
                      onChange={props.handleChange}
                      onBlur={props.handleBlur}
                      value={props.values.telefono}
                    />
                  </div>
                 
            {props.touched.telefono && props.errors.telefono ? (
                        <div className="my-2 bg-red-100 border-l-4 border-red-500 text-red-700 p-4">
                            <p className="font-bold">ERROR</p>
                            <p>{props.errors.telefono}</p>
                        </div>
                        ): null}
            
                  <input
                    type="submit"
                    className="bg-gray-800 w-full mt-5 p-2 text-white uppercas hover:bg-gray-900"
                    value="Editar Cliente"
                  />
                </form>
              );
            }}
          </Formik>
        </div>
      </div>
    </Layout>
  );
};

export default EditarCliente;
