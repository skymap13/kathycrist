import Head from "next/head";
import Layout from "../components/Layout";
import Cliente from "../components/Cliente";
import { gql, useQuery } from "@apollo/client";
import { useRouter } from "next/router";
import Link from "next/link";

const OBTENER_CLIENTE_USUARIO = gql`
  query obtenerClienteVendedor {
    obtenerClienteVendedor {
      id
      nombre
      apellido
      cedula
      email
    }
  }
`;

const Index = () => {

  const router = useRouter();

  //Consulta de Apollo

  const { data, loading, client } = useQuery(OBTENER_CLIENTE_USUARIO);
  //console.log(loading);
  //console.log(error);
  //console.log(data);

 
  if (loading) return 'Loading';
 
  if (loading) {
    return <p>Loading...</p>;
  }
 
  if (!data.obtenerClienteVendedor) {
    client.clearStore();
    router.push('/login');
    return <p>Loading...</p>;
  }







  //if(loading) return 'Cargando...' 

  /*
  if (!data.obtenerClienteVendedor) {
    router.push('/login')
    return <p>Loading...</p>
  }
/*
  
  //--------------------------------VER ERROR
  if (!data ) {
    // El objeto 'data' todavía no está definido, puedes mostrar un mensaje de carga o retornar null.
    return null;
  }
  if (!data.obtenerClienteVendedor) {
    // Si 'data.obtenerClienteVendedor' no existe, redirige al usuario a la página de inicio de sesión.
    router.push('/login');
    return null; // Puedes retornar null aquí o simplemente dejarlo vacío si deseas que no se muestre nada mientras se redirige.
  }
/*
  
  if (!data.obtenerClienteVendedor ) {
    return router.push('/login');

  }*/
  



  


  return (
    <div>
      <Layout>
        <h1 className="text-2xl text-gray-800 font-light">Clientes</h1>
        <Link href="/nuevocliente">
          <p className="bg-blue-800 py-2 px-5 mt-3 inline-block text-white rounded text-sm hover:bg-gray-800 mb-3 uppercase font-bold"> Nuevo Cliente</p>
        </Link>

        <table className="table-auto shadow-md mt-10 w-full w-lg">
          <thead className="bg-gray-800">
            <tr className="text-white">
              <th className="w-1/5 py=2">Nombre</th>
              <th className="w-1/5 py=2">Cedula</th>
              <th className="w-1/5 py=2">Correo</th>
              <th className="w-1/5 py=2">Eliminar</th>
              <th className="w-1/5 py=2">Editar</th>
            </tr>
          </thead>
          {/* 
          <tbody className="bg-white">
            {data.obtenerClienteVendedor.map((cliente) => (
              <tr key={cliente.id}>
                <td className="border px-4 py-2">
                  {cliente.nombre} {cliente.apellido}
                </td>
                <td className="border px-4 py-2">{cliente.cedula}</td>
                <td className="border px-4 py-2">{cliente.email}</td>
              </tr>
            ))}
          </tbody>
          */}

          <tbody className="bg-white">
            {data && data.obtenerClienteVendedor ? (
              data.obtenerClienteVendedor.map((cliente) => (
               <Cliente
                key={cliente.id}
                cliente={cliente}
               />
              ))
            ) : (
              <tr>
                <td colSpan={3} className="border px-4 py-2">
                  No hay datos disponibles.
                </td>
              </tr>
            )}
          </tbody>

          
        </table>
      </Layout>
    </div>
  );
};

export default Index;
